# Verification gates

Do not claim completion from static inspection alone. Record the command, exit code, and relevant evidence for each applicable gate.

## 1. Specification

- `validate_operation.py` passes.
- Mission ID, scene ID, act count, triggers, completion conditions, characters, asset manifest, cinematics, effects, and acceptance shots are explicit.
- No unresolved placeholder wording, contradictory objectives, or missing persistent consequence remains.

## 2. Structure and syntax

- JavaScript syntax checks pass for every changed runtime file.
- Scene and mission IDs are registered exactly once.
- Asset paths resolve locally with correct case and cache version.
- No path escapes, remote runtime dependency, or accidental legacy-root edit was introduced.

## 3. Runtime logic

Create focused tests for scene build and scoped clear, every act transition and repeated trigger, natural/skip/error cinematic cleanup, character route movement from actual scene colliders, spawn visibility/safety and terminal-state cancellation, convoy/checkpoint/failure/victory behavior, optional objective and persistent reward exactly once, destructible/projectile material response, restart, and replay.

## 4. Regression

Run the project's full active test suite and distinguish pre-existing failures from new ones. Confirm previous missions, player controls, weapons, audio, progression, save data, offline loading, character manager, navigation, tactical commands, aiming, and impact systems remain intact.

## 5. Offline visual evidence

Without using a browser, inspect assets and render representative frames with Blender background mode. Use Cycles for final evidence when supported. Required views:

- establishing and horizon composition;
- player spawn and first readable objective;
- each act's principal arena or route;
- close material and texture quality;
- character scale and placement in context;
- rail, road, and convoy alignment where present;
- collision-sensitive choke point;
- cinematic opening and gameplay handoff framing;
- final consequence state.

Actually inspect the rendered pixels. Look for missing textures, black materials, stretched UVs, floating or sunk props, intersecting geometry, wrong scale, empty horizons, repetitive tiling, broken shadows, implausible alignment, and illegible silhouettes.

## 6. User acceptance

Agent-side offline evidence does not replace the user's live gameplay check. Provide the exact alternate-port command only if needed, never touching `8080`. Ask the user to verify pacing, controls, visual density, cinematic skip, character movement, collision feel, and victory cleanup. Report any limitation honestly rather than declaring unobserved browser behavior proven.

## Completion report

Lead with what is playable. List changed operation files, generated or download-required assets, tests with totals, visual evidence locations, cache/version action, user-run command if applicable, and any remaining manual acceptance item.
