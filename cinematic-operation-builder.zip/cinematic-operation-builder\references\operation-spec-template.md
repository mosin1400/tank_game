# Operation specification template

Create one JSON file from this shape and replace every example value with operation-specific content. Arrays may contain more entries, but required keys must remain.

```json
{
  "id": "M02",
  "sceneId": "scene-02",
  "title": "Operation title",
  "act": 1,
  "storyContext": {
    "entry": "What is already true when the operation begins",
    "crisis": "What changes and forces action",
    "climax": "The decisive playable conflict",
    "outcome": "The visible result",
    "nextMissionBridge": "What M03 inherits"
  },
  "location": {
    "region": "Named fictional region",
    "time": "Dawn, day, dusk, or night",
    "weather": "Playable weather and visibility",
    "palette": ["#e6ead1", "#aab668", "#8a9a4e"],
    "terrain": "Dominant ground language",
    "architecture": "Regional construction language",
    "landmarks": ["landmark-a", "landmark-b", "landmark-c"],
    "routes": ["primary route", "tactical alternative"],
    "horizonLayers": ["middle silhouette", "far terrain", "sky and atmosphere"]
  },
  "playerSpawn": {"position": [0, 0, 0], "yaw": 0, "firstSightline": "Readable first landmark"},
  "objectives": {
    "primary": "Observable primary objective",
    "optional": "Non-blocking mastery objective",
    "failure": ["Understandable failure condition"],
    "reward": "Reward or unlock",
    "persistentEffect": "Later visible consequence"
  },
  "acts": [
    {"id": "act-1", "title": "Orientation under pressure", "entryTrigger": "Operation starts after cinematic cleanup", "goal": "Immediate player goal", "pressure": "Enemy, environment, or time pressure", "storyBeat": "What the player learns", "spatialChange": "What opens, closes, moves, burns, floods, or becomes visible", "completion": "Deterministic state condition"},
    {"id": "act-2", "title": "Complication and commitment", "entryTrigger": "Act 1 completion", "goal": "Changed player goal", "pressure": "New tactical pressure", "storyBeat": "Reversal or reveal", "spatialChange": "Changed route, visibility, or ally state", "completion": "Deterministic state condition"},
    {"id": "act-3", "title": "Climax and consequence", "entryTrigger": "Act 2 completion", "goal": "Climactic goal", "pressure": "Combined learned threats", "storyBeat": "Resolution", "spatialChange": "Final world-state change", "completion": "Victory condition"}
  ],
  "characters": [
    {"rosterId": "existing-roster-id", "role": "Narrative or tactical role", "faction": "Registered faction", "position": [0, 0, 0], "yaw": 0, "weapon": "existing-weapon-id", "initialState": "idle", "behavior": "Route, cover, reaction, and cleanup policy"}
  ],
  "encounters": [
    {"id": "encounter-1", "actId": "act-1", "purpose": "Scout, flank, deny route, attack ally, or protect target", "trigger": "Zone, objective, or world-state trigger", "staging": "Off-screen credible staging area", "approach": "Validated route to contact", "composition": ["enemy type and count"], "endCondition": "Deterministic completion", "terminalGuard": true}
  ],
  "cinematics": [
    {"id": "opening", "kind": "opening", "skippableFromFrame": 0, "purpose": "Place, threat, objective, orientation", "beats": ["establishing", "threat", "tank reveal", "objective handoff"], "cleanup": "Exactly-once restoration contract"}
  ],
  "effects": ["Operation-specific weather, sound, impact, destruction, or machinery effects"],
  "assets": {
    "texturesToGenerate": ["Texture manifest entry"],
    "modelsToRequest": [],
    "audioToReuse": ["Existing audio ID"],
    "sharedSystems": ["CharacterManager", "navigation", "impact", "tactical command"]
  },
  "acceptance": {
    "logicTests": ["Act transition", "terminal spawn guard", "restart and unload"],
    "regressionTests": ["Full active suite"],
    "renderShots": ["establishing", "spawn", "act-1", "act-2", "act-3", "material-closeup", "final-state"],
    "liveChecks": ["pacing", "cinematic skip", "movement", "collision", "victory cleanup"]
  }
}
```
