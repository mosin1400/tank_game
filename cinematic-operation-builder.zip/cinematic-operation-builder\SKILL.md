---
name: cinematic-operation-builder
description: Design, implement, art-direct, and verify one story-driven cinematic operation at a time for the modular browser-only Three.js tank campaign. Use when turning an approved campaign mission into a distinct playable chapter with its own environment, encounters, cinematics, effects, and runtime integration; do not use for generating, rigging, or authoring the shared human character and animation assets.
---

# Cinematic Operation Builder

Build one operation as a complete playable chapter. Preserve every existing capability and make the smallest compatible changes outside the operation's own files.

## Non-negotiable boundaries

- Treat the shared character models, rigs, texture variants, weapons, and animation library as finished infrastructure. Never recreate, rerig, retarget, download, or document their production pipeline.
- Reuse the project's character manager, roster IDs, animation states, navigation, combat reactions, and weapon attachment APIs.
- Never use a browser, browser-control tool, or browser screenshot as a rendering pipeline. Use deterministic tests and Blender renders for agent-side visual evidence; ask the user to perform the final live browser playthrough when needed.
- Port `8080` is permanently occupied. Never bind it, probe it destructively, terminate its process, or suggest taking it over. If an HTTP server is necessary, confirm and use a free port in `8081-8099`.
- When Blender is necessary, run it from the command line in background mode. Use Cycles for final evidence renders when supported; use Eevee only for labeled fast previews.
- Use the built-in image-generation tool for bespoke terrain, surface, decal, backdrop, sky, or prop textures. Do not replace requested image generation with CSS, canvas, Python drawing, ImageMagick, or procedural placeholder bitmaps.
- If a suitable 3D asset is missing, do not silently substitute a crude primitive as final art. Give the user an asset request containing purpose, visual description, approximate dimensions, preferred format (`GLB` or `FBX`), texture requirements, polygon budget, animation/rig requirement, and acceptable license. Continue only with an explicitly labeled blockout until the asset arrives.
- Do not delete or weaken weapons, controls, audio, progression, save data, offline loading, tactical systems, impacts, destruction, accessibility, or prior missions.

## Required workflow

1. Establish the real checkout, served entry point, current mission data, scene registry, story documents, and dirty-worktree state. Do not confuse the legacy root game with the modular worktree.
2. Read [references/operation-workflow.md](references/operation-workflow.md) and execute its gates in order.
3. During narrative design, read [references/narrative-level-design.md](references/narrative-level-design.md) and instantiate [references/operation-spec-template.md](references/operation-spec-template.md).
4. Validate the completed JSON specification with `python scripts/validate_operation.py <operation.json>` before scene implementation.
5. During environment construction and asset production, read [references/environment-art-pipeline.md](references/environment-art-pipeline.md).
6. During encounter and character placement, read [references/encounters-and-progression.md](references/encounters-and-progression.md).
7. During opening, transition, and ending cinematic work, read [references/cinematic-design.md](references/cinematic-design.md).
8. During code integration, read [references/gameplay-integration.md](references/gameplay-integration.md).
9. Before claiming completion, read and satisfy [references/verification-gates.md](references/verification-gates.md).

## Completion contract

An operation is complete only when its story has a meaningful beginning, escalation, climax, and consequence; its environment is visually distinct at near, middle, and horizon ranges; all progression triggers are deterministic; characters have purposeful placement and behavior; cinematics are skippable and clean up exactly once; collision and navigation work; victory prevents further spawning; and structural, runtime, regression, and offline Blender visual checks pass. Static counts alone never prove visual acceptance.
