# Cinematic design

## Opening cinematic contract

The opening must establish, in order:

1. geographic identity and atmosphere;
2. evidence of the current campaign situation;
3. immediate threat or disruption;
4. the player's tank and relationship to nearby forces;
5. a clear visual handoff to the first playable objective.

Prefer 20-45 seconds. Every shot needs a story or orientation purpose. Avoid slow empty pans, cameras crossing geometry, excessive depth-of-field, or action that the player cannot later locate.

## Camera and state

- Use named camera beats with explicit start/end transforms, target, duration, easing, subtitle cue, audio cue, and optional world event.
- Validate clipping and occlusion against final geometry.
- Lock gameplay input without stopping world animation that the cinematic depends on.
- During cinematic mode hide the complete gameplay HUD, radar, crosshair, weapons, health, touch controls, tactical commands, and damage overlays.
- Keep only the narrative subtitle layer. Configure skip input from the first frame; do not require a visible gameplay button.
- On handoff, restore the exact camera mode, input state, audio mix, HUD state, and mission clock required by play.

## Exactly-once cleanup

Natural completion, skip, restart, mission unload, and thrown errors must converge on one idempotent cleanup function. That function cancels scheduled beats, stops cinematic-only audio, removes temporary objects/listeners/classes, restores runtime state, and invokes continuation no more than once.

## Transition and ending beats

Use in-mission transition cinematics only for a meaningful spatial or story change. Keep them short and preserve urgency. The ending should show the consequence the player caused rather than only displaying victory text. Essential information must remain available in the next objective or briefing if any cinematic is skipped.

## Subtitles and audio

Use short Persian subtitle lines with speaker IDs consistent with the character bible. Keep the subtitle clear of letterbox framing and safe areas. Duck combat audio rather than muting the world completely. Radio filtering, distant artillery, machinery, wind, rain, and alarms should support the location rather than form an undifferentiated loud bed.
