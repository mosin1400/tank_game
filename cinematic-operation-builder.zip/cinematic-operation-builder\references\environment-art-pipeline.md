# Environment art and background pipeline

## Four depth layers

Build all four layers deliberately:

1. **Near field:** wheel-scale ground detail, ruts, ballast, puddles, rubble, shell marks, grass clumps, cables, debris, and cover contacts.
2. **Playable middle field:** roads, rails, bridges, compounds, buildings, props, fortifications, vegetation groups, objective silhouettes, and traversal openings.
3. **Far field:** terrain shoulders, distant settlements, industrial silhouettes, tree masses, ridgelines, smoke columns, infrastructure continuation, and parallax layers.
4. **Sky/atmosphere:** time of day, cloud structure, sun direction, haze color, fog depth, precipitation, and aerial threat readability.

Do not use a single flat backdrop to replace missing geography. Distant geometry may be low-detail, but scale, silhouette, lighting, and atmospheric perspective must remain coherent.

## Texture manifest before generation

For every new texture record:

- asset ID and target object/surface;
- narrative purpose and era/weather state;
- tileable or unique;
- required resolution and aspect ratio;
- base color, normal, roughness, metalness, alpha, emissive, or decal channels;
- real-world texel scale;
- edge/seam behavior;
- color-space rule (`sRGB` for base color/emissive, linear for data maps);
- provenance, license, and generated-source note.

Use image generation with a precise material prompt. Ask for orthographic, evenly lit, shadow-free, perspective-free output for tileable surfaces. Ask for transparent background and clean masks for decals. Generate separate visual concepts for skies or distant panorama layers; do not pretend a beauty image is a physically correct PBR set.

Inspect generated images at full resolution. Reject baked directional shadows, perspective distortion, visible seams, text artifacts, inconsistent scale, repeated hero objects, or channels that do not represent their claimed physical quantity.

## Geometry and asset sourcing

Use procedural Three.js geometry for low-focus structural pieces when its silhouette is credible. Use authored geometry for hero props, complex vehicles, recognizable machinery, damaged architecture, and objects seen close to the camera.

When the user must download a model, request exactly one manifest entry per asset:

```text
Asset: damaged railway signal
Use: Mxx middle-field landmark and objective
Preferred: GLB 2.0, embedded PBR textures
Scale: meters; approximately 5 m tall
Budget: 20k-80k triangles
Rig/animation: none
License: CC0 or commercial-use attribution-compatible
Variants: intact and damaged if available
```

Do not claim a blockout primitive is final. Keep missing-model placeholders named and isolated so replacement does not disturb logic or colliders.

## Alignment and collision

- Derive rails, sleepers, wagons, platforms, roads, fences, and convoy paths from shared frames/splines.
- Apply and verify transforms before generating collision bounds.
- Use OBB for rotated rectangular objects, circle/capsule for radial objects, and mesh/raycast detail only when gameplay requires it.
- Attach destructible collider metadata to the visible target object.
- Leave recovery margins around routes and spawn points.
- Never add a static obstacle for a moving character; dynamic character avoidance and projectile hit volumes own that responsibility.

## Blender evidence

Use Blender only when it materially improves asset inspection, lighting proof, scale comparison, or scene composition. Run from CLI in background mode and save scripts/results in a temporary or documented tool-output directory. Final evidence uses Cycles when supported. Render at least:

- one wide establishing view;
- one route/landmark composition view;
- one close surface/material view;
- one collision-sensitive choke point;
- one representative combat-lighting view.

Label Eevee previews as previews. Never treat polygon counts, image dimensions, file existence, or successful export as proof of visual quality.
