# Narrative and level design

## Continuity pass

Read the approved campaign arc first, then the previous, current, and next mission entries. Extract:

- what the player knows at entry;
- unresolved personal and military stakes;
- campaign flags that change this operation;
- what must be revealed, earned, damaged, rescued, or lost here;
- the emotional transition this operation owns;
- information the next operation requires.

Strengthen connective tissue, but do not rewrite the campaign premise, erase established consequences, resurrect destroyed assets, or introduce a faction/character without registering it in existing data contracts.

## Playable dramatic structure

Use at least three acts, normally 8-15 minutes each for a substantial operation:

1. **Orientation under pressure:** teach the space and immediate threat while preserving agency.
2. **Complication and commitment:** change the route, objective, ally state, weather, visibility, or enemy plan. Make returning to the original solution insufficient.
3. **Climax and extraction/consequence:** combine learned mechanics and force a meaningful priority. Victory should change the visible world or campaign state.

Add breathing intervals between high-pressure beats. A long mission needs checkpoints and evolving objectives, not inflated enemy health or repetitive waves.

## Objective quality

Every operation needs:

- one clear primary objective whose progress is visible;
- one optional objective that rewards mastery but never blocks continuation;
- at least one environmental or tactical pressure besides enemy health;
- explicit failure conditions that the player can understand and influence;
- a deterministic victory condition;
- a consequence reflected in later briefing, map, scene, enemy roster, support, or route.

Avoid objectives described only as "kill all enemies." Use escort, hold, intercept, disable, protect, scan, reach, choose route, operate machinery, mark targets, preserve infrastructure, or survive a changing environment.

## Spatial storytelling

Assign every major landmark at least two purposes from this list: navigation, cover, objective, cinematic framing, environmental story, destructible opportunity, sound source, tactical choice, or horizon identity. Compose a readable path through silhouettes and light, not floating arrows alone.

## Dialogue

Dialogue must be short enough to survive combat, tied to observable events, and assigned to an existing role ID. Separate essential objective information from flavor. If a cinematic is skipped, repeat essential facts in the HUD objective, radio, or next briefing. Preserve Persian wording direction and character naming conventions already used by the project.
