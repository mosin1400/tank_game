#!/usr/bin/env python3
"""Validate a cinematic operation specification using only the standard library."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import Any


REQUIRED_TOP = {
    "id": str,
    "sceneId": str,
    "title": str,
    "act": int,
    "storyContext": dict,
    "location": dict,
    "playerSpawn": dict,
    "objectives": dict,
    "acts": list,
    "characters": list,
    "encounters": list,
    "cinematics": list,
    "effects": list,
    "assets": dict,
    "acceptance": dict,
}

NESTED_REQUIRED = {
    "storyContext": ("entry", "crisis", "climax", "outcome", "nextMissionBridge"),
    "location": ("region", "time", "weather", "palette", "terrain", "architecture", "landmarks", "routes", "horizonLayers"),
    "playerSpawn": ("position", "yaw", "firstSightline"),
    "objectives": ("primary", "optional", "failure", "reward", "persistentEffect"),
    "assets": ("texturesToGenerate", "audioToReuse", "sharedSystems"),
    "acceptance": ("logicTests", "regressionTests", "renderShots", "liveChecks"),
}

ACT_FIELDS = ("id", "title", "entryTrigger", "goal", "pressure", "storyBeat", "spatialChange", "completion")
CHARACTER_FIELDS = ("rosterId", "role", "faction", "position", "yaw", "weapon", "initialState", "behavior")
ENCOUNTER_FIELDS = ("id", "actId", "purpose", "trigger", "staging", "approach", "composition", "endCondition", "terminalGuard")
CINEMATIC_FIELDS = ("id", "kind", "skippableFromFrame", "purpose", "beats", "cleanup")


def nonempty(value: Any) -> bool:
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (list, dict)):
        return bool(value)
    return value is not None


def require_fields(errors: list[str], value: Any, fields: tuple[str, ...], label: str) -> None:
    if not isinstance(value, dict):
        errors.append(f"{label} must be an object")
        return
    for field in fields:
        if field not in value or not nonempty(value[field]):
            errors.append(f"{label}.{field} is required and must not be empty")


def validate(data: Any) -> list[str]:
    errors: list[str] = []
    if not isinstance(data, dict):
        return ["root must be a JSON object"]

    for field, expected_type in REQUIRED_TOP.items():
        if field not in data:
            errors.append(f"{field} is required")
        elif not isinstance(data[field], expected_type) or not nonempty(data[field]):
            errors.append(f"{field} must be a non-empty {expected_type.__name__}")

    mission_id = data.get("id")
    scene_id = data.get("sceneId")
    if isinstance(mission_id, str) and not re.fullmatch(r"M(?:0[1-9]|[1-3][0-9]|40)", mission_id):
        errors.append("id must be M01 through M40")
    if isinstance(scene_id, str) and not re.fullmatch(r"scene-(?:0[1-9]|[1-3][0-9]|40)", scene_id):
        errors.append("sceneId must be scene-01 through scene-40")
    if isinstance(mission_id, str) and isinstance(scene_id, str) and mission_id[1:] != scene_id[-2:]:
        errors.append("id and sceneId numeric suffixes must match")
    if isinstance(data.get("act"), int) and not 1 <= data["act"] <= 4:
        errors.append("act must be an integer from 1 through 4")

    for section, fields in NESTED_REQUIRED.items():
        if section in data:
            require_fields(errors, data[section], fields, section)

    assets = data.get("assets")
    if isinstance(assets, dict) and not isinstance(assets.get("modelsToRequest"), list):
        errors.append("assets.modelsToRequest is required and must be a list; it may be empty")

    spawn = data.get("playerSpawn", {}).get("position") if isinstance(data.get("playerSpawn"), dict) else None
    if not isinstance(spawn, list) or len(spawn) != 3 or not all(isinstance(v, (int, float)) for v in spawn):
        errors.append("playerSpawn.position must contain exactly three numbers")

    acts = data.get("acts")
    act_ids: set[str] = set()
    if isinstance(acts, list):
        if len(acts) < 3:
            errors.append("acts must contain at least three playable acts")
        for index, act in enumerate(acts):
            require_fields(errors, act, ACT_FIELDS, f"acts[{index}]")
            if isinstance(act, dict) and isinstance(act.get("id"), str):
                if act["id"] in act_ids:
                    errors.append(f"acts[{index}].id duplicates {act['id']}")
                act_ids.add(act["id"])

    characters = data.get("characters")
    if isinstance(characters, list):
        for index, character in enumerate(characters):
            require_fields(errors, character, CHARACTER_FIELDS, f"characters[{index}]")
            position = character.get("position") if isinstance(character, dict) else None
            if not isinstance(position, list) or len(position) != 3 or not all(isinstance(v, (int, float)) for v in position):
                errors.append(f"characters[{index}].position must contain exactly three numbers")

    encounters = data.get("encounters")
    if isinstance(encounters, list):
        for index, encounter in enumerate(encounters):
            require_fields(errors, encounter, ENCOUNTER_FIELDS, f"encounters[{index}]")
            if isinstance(encounter, dict):
                if encounter.get("actId") not in act_ids:
                    errors.append(f"encounters[{index}].actId must reference an existing act")
                if encounter.get("terminalGuard") is not True:
                    errors.append(f"encounters[{index}].terminalGuard must be true")

    cinematics = data.get("cinematics")
    if isinstance(cinematics, list):
        opening_found = False
        for index, cinematic in enumerate(cinematics):
            require_fields(errors, cinematic, CINEMATIC_FIELDS, f"cinematics[{index}]")
            if isinstance(cinematic, dict) and cinematic.get("kind") == "opening":
                opening_found = True
                if cinematic.get("skippableFromFrame") != 0:
                    errors.append("opening cinematic must be skippable from frame 0")
        if not opening_found:
            errors.append("cinematics must include one opening cinematic")

    location = data.get("location")
    if isinstance(location, dict):
        for field, minimum in (("landmarks", 3), ("routes", 1), ("horizonLayers", 3)):
            value = location.get(field)
            if not isinstance(value, list) or len(value) < minimum:
                errors.append(f"location.{field} must contain at least {minimum} entries")

    acceptance = data.get("acceptance")
    if isinstance(acceptance, dict):
        for field in ("logicTests", "regressionTests", "renderShots", "liveChecks"):
            if not isinstance(acceptance.get(field), list) or not acceptance[field]:
                errors.append(f"acceptance.{field} must be a non-empty list")

    return errors


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: validate_operation.py <operation.json>", file=sys.stderr)
        return 2
    path = Path(sys.argv[1])
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except FileNotFoundError:
        print(f"ERROR: file not found: {path}", file=sys.stderr)
        return 2
    except json.JSONDecodeError as exc:
        print(f"ERROR: invalid JSON at line {exc.lineno}, column {exc.colno}: {exc.msg}", file=sys.stderr)
        return 2
    errors = validate(data)
    if errors:
        print(f"FAIL: {len(errors)} validation error(s)", file=sys.stderr)
        for error in errors:
            print(f"- {error}", file=sys.stderr)
        return 1
    print(f"PASS: {data['id']} / {data['sceneId']} operation specification is valid")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
