# Encounters, actors, and progression

## Character placement

Use only registered shared character assets. For every character instance define:

- roster ID, faction, narrative role, and whether gameplay-critical;
- world position, yaw, initial animation state, weapon, and look target;
- route/waypoints, speed, start trigger, cover preferences, and safe fallback;
- reactions to shelling, nearby enemies, player fire, blocked route, and objective completion;
- dialogue cues and cleanup owner.

Characters should look occupied before the player arrives: guarding, observing, repairing, signaling, loading, treating casualties, or moving between credible work points. During bombardment, exposed allies seek cover or relocate instead of idling. Protected story characters may react without taking damage when the operation requires it.

## Spawn discipline

- Stage enemies behind terrain, structures, fog, gates, tunnels, transport, or distant approach routes.
- Validate their route from staging to contact before enabling the wave.
- Never spawn an enemy directly inside the player's current view or collision radius unless it is an intentional, telegraphed breach.
- Cap live units for performance and pacing. Reuse pools only after state and ownership are fully reset.
- Gate every spawn by active mission state and terminal state. Victory, defeat, restart, and unload must cancel queued spawns.

## Three-act controller

Represent progression with named states, not a loose set of timers. A typical shape is:

```text
INTRO -> ACT_1 -> ACT_1_TRANSITION -> ACT_2 -> ACT_2_TRANSITION -> ACT_3 -> VICTORY
                                           \-> FAILURE
```

Each transition must be idempotent. Store cancellation handles for timeouts, audio, cinematic tracks, pending waves, and listeners. Re-entering a state may update UI but must not duplicate enemies, rewards, dialogue, or campaign flags.

## Wave design

Each wave needs a tactical job: scout, fix the player, flank, deny a route, attack an ally, protect a target, counterattack after sabotage, or cover retreat. Change composition and approach rather than only increasing quantity. Combine tanks, guns, infantry, aircraft, and environmental threats only when readable counterplay exists.

Use triggers such as zone entry, objective completion, convoy position, destroyed infrastructure, detected player, radio event, or persistent campaign flag. Timers may shape cadence but should not be the only causal logic.

## Pacing and duration

Make long operations compelling through new information and changed decisions. Alternate observation/orientation, movement and route choice, short combat pressure, interaction/protection, escalation or environmental change, and climax/extraction.

Checkpoint at stable narrative boundaries. Restore all required operation state from a checkpoint or deliberately restart the act; never restore only the player's position while leaving triggers inconsistent.
