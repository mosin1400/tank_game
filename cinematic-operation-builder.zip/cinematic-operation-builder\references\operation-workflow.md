# Operation workflow

Use one operation ID per run. Finish each gate before moving to the next. Preserve evidence and report progress after every gate.

## Gate 0: establish scope and baseline

1. Confirm the actual checkout, entry HTML, build/cache version, mission ID, scene ID, and existing server ownership.
2. Inspect `git status` and preserve all unrelated changes.
3. Read the campaign arc, character bible, previous/current/next mission records, persistent campaign flags, and existing runtime contracts.
4. Run the relevant existing tests before editing. Record failures as baseline; do not attribute them to new work.
5. Inventory reusable terrain, materials, props, audio, effects, shared characters, enemies, tanks, controls, and mission systems.

Deliverable: a short baseline report identifying story continuity, reusable systems, missing assets, and files expected to change.

## Gate 1: narrative and playable specification

1. Expand the mission entry without contradicting the approved 40-mission arc.
2. Define why the player enters, why withdrawal is impossible or costly, how the situation changes, what the climax demands, and what persists afterward.
3. Design at least three playable acts. Each act needs an entry trigger, player goal, opposing pressure, spatial change, story beat, and deterministic completion condition.
4. Define the primary objective, optional objective, failure conditions, checkpoint policy, reward, persistent consequence, and what the next mission learns from this result.
5. Define a visual bible: palette, weather, time, visibility, terrain language, architecture, damage history, silhouettes, landmark hierarchy, and forbidden visual clichés.
6. Fill the operation JSON using `operation-spec-template.md`, validate it, then obtain user approval if the operation concept was not already approved.

Deliverable: validated operation specification and asset manifest.

## Gate 2: spatial blockout

1. Establish one coordinate frame and named anchors for player spawn, routes, zones, landmarks, encounter staging, cover, exits, and cinematic cameras.
2. Block out the complete traversable area, not only the combat pocket. Include plausible approaches, inaccessible background continuation, and horizon composition.
3. Drive roads, rails, bridges, wagons, fences, and convoy paths from shared frames or splines. Never align dependent objects independently by eye.
4. Place representative collision volumes immediately and test player clearance, firing lanes, AI routes, camera occlusion, and recovery space.
5. Keep enemies out of direct spawn sight unless the story explicitly opens under fire and gives readable protection.

Deliverable: readable grayscale/block-material scene with validated scale and traversal.

## Gate 3: environment art and background

1. Build near, middle, far, and sky layers from the approved visual bible.
2. Generate and integrate final textures with correct color space, tiling, UV scale, PBR channel use, edge treatment, and provenance.
3. Replace blockout primitives that carry visual focus with authored geometry or approved downloaded models.
4. Add environmental storytelling: logistics, wear, tracks, repair traces, shelling, debris, signage, defensive preparation, and evidence of recent activity.
5. Produce offline evidence renders before encounter logic makes the scene difficult to inspect.

Deliverable: visually complete static operation environment.

## Gate 4: actors, encounters, and playable progression

1. Spawn shared characters by roster ID and assign narrative role, faction, weapon, initial pose, look target, route, cover logic, and reaction policy.
2. Add enemies and waves only when their staging, travel route, line of sight, and tactical purpose are credible.
3. Implement the operation controller as an explicit state machine. Events must be idempotent and cleanly cancellable.
4. Connect dialogue, checkpoints, convoy state, environmental changes, reinforcements, optional objectives, failure, victory, and persistent effects.
5. Ensure pacing alternates pressure, navigation, observation, decision, and combat. Do not reduce an act to waiting for a timer or killing every target.

Deliverable: complete three-act playable loop without cinematics.

## Gate 5: cinematic and presentation

1. Implement a skippable opening cinematic that establishes place, immediate threat, objective, and player orientation.
2. Add short transition beats only where the playable state materially changes.
3. Hide all gameplay HUD, touch controls, damage overlays, weapon selectors, radar, and command buttons while cinematic mode is active. Keep only the narrative subtitle layer; skipping must still be available through configured input.
4. Restore camera, controls, audio mix, HUD, timers, and state exactly once on natural completion, skip, restart, unload, or error.
5. Repeat any essential skipped information in the playable objective or briefing.

Deliverable: cinematic flow integrated without duplicate starts or leaked locks.

## Gate 6: effects, polish, and acceptance

1. Add only operation-relevant weather, lighting changes, soundscape, impacts, destruction, fires, smoke, radio, aircraft, water, or machinery.
2. Connect projectile response to material class and durability. Dynamic characters use dynamic hit volumes; never leave a fixed navigation collider at their spawn.
3. Verify the whole operation, its restart/unload path, previous mission contracts, shared runtime, and post-victory terminal state.
4. Produce final offline evidence renders and request the user's live playthrough on an alternate confirmed-free port if browser runtime acceptance is required.

Deliverable: evidence-backed handoff with remaining limitations stated explicitly.
