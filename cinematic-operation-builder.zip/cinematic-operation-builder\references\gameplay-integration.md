# Gameplay integration

Follow the existing project's patterns after inspecting them; filenames below describe responsibilities, not permission to invent parallel systems.

## Data and registration

- Give the operation one stable mission ID and one stable scene ID.
- Keep story, briefing, objective, enemy, air, reward, and persistent-effect data in mission data rather than hardcoding display text into combat logic.
- Register the scene in the existing scene library and confirm missing IDs fail safely.
- Keep scene configuration separate from generic builders and shared runtime systems.
- Add a cache-version change when shipped JavaScript, CSS, manifests, models, or textures could otherwise remain stale.

## Scene ownership

The operation's scene handle owns its root, static colliders, destructible registrations, temporary lights/effects, and spawned operation actors. Clear/unload must remove exactly those resources and restore legacy visibility/runtime state without touching another scene.

Dynamic characters are owned by the character manager and navigation/combat systems. Do not add a second fixed collider at their initial position. Remove characters through the manager's scoped cleanup API.

## Collision and projectile response

- Colliders must match final transforms and visible dimensions.
- Moving targets update their hit volumes.
- Strong surfaces receive penetration marks, dents, sparks, ricochets, or localized damage according to angle/material.
- Weak surfaces fracture or transition to a damaged state without leaving invisible blockers.
- Ground hits create a small localized dust, soil, snow, or water response appropriate to the material.
- Story-protected allies may react while their health remains unchanged, if specified.

## Navigation

Build a live navigation test from the real operation scene, not a hand-authored approximation. Assert that each scripted moving character can leave its spawn, advance a meaningful distance, enter the intended locomotion state, avoid static colliders, avoid allies, and reject routes toward hostile control areas when required.

## Terminal states

All spawn entry points and queued callbacks must check active operation and terminal state. Victory must stop future waves, detach combat listeners, commit rewards once, and allow a clean restart/replay. Defeat and unload need equivalent cancellation without granting rewards.

## Port and runtime discipline

Never bind or stop port `8080`. For user-run live testing, find a free port from `8081` through `8099`, report the exact command and URL, and leave ownership visible. Do not use a browser yourself. If no safe port is available, rely on structural/runtime tests and ask the user to use their existing server.

## Compatibility

Before editing shared modules, prove the operation cannot be implemented through scene data or a scoped extension. If a shared change is necessary, add regression tests covering existing missions and preserve public APIs wherever possible.
